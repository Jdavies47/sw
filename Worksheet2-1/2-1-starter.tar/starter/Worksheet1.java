/** @author 
 * <PUT YOUR NAME HERE>
 * This class contains the solution for Worksheet1
 */

public class Worksheet1 implements Worksheet1Interface {

  public static int power(int m, int n) {
			return 0; // replace this by your code
	}

  public static int fastPower(int m, int n) {
			return 0; // replace this by your code
	}

	public static List negateAll(List a) {
			return List.empty(); //replace this by your code
	}

	public static int find(int x, List a) {
			return 0; //replace this by your code
	}

	public static boolean allPositive(List a) {
			return true; //replace this by your code
	}

	public static List positives(List a) {
			return List.empty(); //replace this by your code
	}

	public static boolean sorted(List a) {
			return true; //replace this by your code
	}

	public static List merge(List a, List b) {
			return List.empty(); //replace this by your code
	}

	static List removeDuplicates(List a) {
			return List.empty(); //replace this by your code
	}

}
