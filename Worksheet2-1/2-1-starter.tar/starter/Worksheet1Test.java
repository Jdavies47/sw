import static org.junit.Assert.*;

import org.junit.Test;

/** @author 
 *  <PUT YOUR NAME HERE>
 * This class contains the test cases for Worksheet1 solutions.
 *  <WRITE YOUR TEST CASES BELOW>
 */

public class Worksheet1Test {

}
