/** @author 
 *  Uday Reddy
 *  This is the interface for your solution for Worksheet1
 ***  DO NOT MODIFY THIS FILE ***
 */

public interface Worksheet1Interface {

  public static int power(int m, int n) {
			return 0; 
	}

  public static int fastPower(int m, int n) {
			return 0; 
	}

	public static List negateAll(List a) {
			return List.empty(); 
	}

	public static int find(int x, List a) {
			return 0; 
	}

	public static boolean allPositive(List a) {
			return true; 
	}

	public static List positives(List a) {
			return List.empty(); 
	}

	public static boolean sorted(List a) {
			return true; 
	}

	public static List merge(List a, List b) {
			return List.empty(); 
	}

	static List removeDuplicates(List a) {
			return List.empty(); 
	}

}
