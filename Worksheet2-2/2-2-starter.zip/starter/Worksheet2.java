/** @author 
 * 
 * This class contains the solution for Worksheet2
 */

public class Worksheet2 implements Worksheet2Interface {
    // Exercise 1

    public static Tree negateAll(Tree t) {
				return new Tree();
    }

    // Exercise 2

    public static Tree mirror(Tree t) {
				return new Tree();
		}

    // Exercise 3

    public static List postorder(Tree t) {
				return List.empty();
    }


    // Exercise 4

    public static boolean allPositive(Tree a) {
				return true;
    }

		// Exercise 5

    public static boolean isSearchTree(Tree a) {
				return true;
    }

    // Exercise 6

    public static void printDescending(Tree a) {
    }

		// Exercise 7

    public static int max(Tree a) {
				return 0;
    }

    // Exercise 8

    public static Tree delete(Tree a, int x) {
				return new Tree();
    }

		// Exercise 9
    public static boolean isHeightBalanced(Tree a) {
				return true;
    }

		// Exercise 10

    public static Tree insertHB(int x, Tree a) {
				return new Tree();
    }

    public static Tree deleteHB(Tree a, int x) {
				return new Tree();
    }
    
}
